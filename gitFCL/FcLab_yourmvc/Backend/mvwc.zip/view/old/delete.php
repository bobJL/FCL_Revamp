<?php include 'header.php'; ?>

<?php
echo $contacts;
?>

<?php include 'footer.php'?>

