<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>title</title>
    <meta name="author" content="name">
    <meta name="description" content="description here">
    <meta name="keywords" content="keywords,here">
    <link rel="stylesheet" href="jouw_stylesheet.css" type="text/css">
    <script type="text/javascript" src=""></script>
    <noscript>Please turn on javascript in your browser settings</noscript>
</head>
<body>

    <h1>Read Products</h1>

    <button>Create New Product</button>

    <?php //echo $products;
        var_dump($products);
    ?>

</body>
</html>